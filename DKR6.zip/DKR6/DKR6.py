c = ['123', '456', '789']
cu = 0
g = "далее"
def show():
	print("Текущий элемент: ", c[cu])
	print("Чтобы перейти к следующему элементу введите 'далее'")
	print("Чтобы перейти к предыдущему элементу введите 'назад'")
	print("Чтобы добавить новый элемент введите значение")
	print("Чтобы удалить текущий элемент введите 'удалить'")
	print("Чтобы показать все элементы введите 'список'")
	print("Чтобы закрыть программу введите 'выйти'")
	n_g()
def n_g():
	global g
	g = input()
	menu()
def menu():
	global cu
	global c
	match g:
		case "далее":
			if len(c) > cu+1:
				cu += 1
			else:
				cu = 0
			show()
		case "назад":
			if cu == 0:
				cu = len(c) -1
			else:
				cu -= 1
			show()
		case "выйти":
			exit
		case "удалить":
			print("Элемент ", c.pop(cu), " успешно удален")
			show()
		case "список":
			print(c)
			show()
		case _:
			c.insert(cu+1, g)
			print("Элемент ", g, " успешно добавлен")
			n_g()
show()